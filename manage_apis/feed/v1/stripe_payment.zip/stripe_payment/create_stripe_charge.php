<?php

ini_set("display_errors", "0");
include_once('../../../web-config.php'); 
include_once('../../../includes/classes/DBQuery.php'); 
include_once('../../../includes/functions/common.php'); 

require_once('stripe-php/init.php');

$userDetails = $_REQUEST;


$userEmail = $userDetails['email'];
$paymentAmount = $userDetails['amount'];
$stripeToken = $userDetails['token'];
$stripeAPIToken_Key = $userDetails['stripeAPITokenKey'];
$app_id = $userDetails['appID'];
$stream_guid = $userDetails['streamGuid'];
$menu_guid = $userDetails['menuGuid'];
$payment_currency = $userDetails['paymentCurrency'];
$payment_descrition = $userDetails['paymentDescription'];
$user_code = $userDetails['userCode'];

\Stripe\Stripe::setApiKey($stripeAPIToken_Key);

// Token is created using Stripe Checkout or Elements!
// Get the payment token ID submitted by the form:
$chargeResponse = \Stripe\Charge::create([
  'amount' => $paymentAmount,
  'currency' => $payment_currency,
  'description' => $payment_descrition,
  'source' => $stripeToken,
]);

/*
$appInfoArr = $objDBQuery->getRecord(0, '*', 'tbl_apps', "appCode = '".$app_id, '', '', '', '');

if (!empty($appInfoArr) && is_array($appInfoArr))
{					
  //echo "<br>cnt2= ".
  $numOfRows4App = count($appInfoArr);
  if ( $numOfRows4App > 0)
  {						
    $emailSMTPDetails = $appInfoArr[0];
  }
}
*/
$ipAdd = getRealIpAddr();
$arrTrkPaymentInsert = array('userCode_FK' => $user_code, 'stripe_charges_token' => $stripeToken, 'appCode_FK' => $appCode, 
'payment_amount' => $paymentAmount, 'gateway_type'=>'Stripe', 'payment_currency' => $payment_currency, 
'payment_status' => $chargeResponse['status'], 'ipAddress', $ipAdd);
$objDBQuery->addRecord(0, $arrTrkPaymentInsert, 'tbl_track_swigit_payment');

//$emailFormatInfoArr = $objDBQuery->getEmailFormat(0, $appCode, 'app-change-password');
//$arrEmailInfo = prepareEmailFormat(array(0, 0), $emailFormatInfoArr, $objDBQuery, $appCode, $name, '', $password);

//sendEmailSwigit($email, $arrEmailInfo, 'HTML');

//print_r($chargeResponse);
header("Content-type:application/json; charset=UTF-8");
echo $chargeResponseStr = json_encode($chargeResponse, JSON_PRETTY_PRINT);



?>